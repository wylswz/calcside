SELECT status,error_code,count(*) FROM runs
WHERE application_id='app_qclqnMmJNbcof7zFPlqjpTmu'
AND created_at>='2026-11-14T14:14:19.075897+00:00'
AND created_at<='2026-11-14T14:14:52.777285+00:00'
GROUP BY status,error_code ORDER BY status,error_code;
